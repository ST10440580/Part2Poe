/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poepart2;
 

/**
 *
 * @author Windows 10
 */
public class POEpart2 {
 /**
     * @param args the command line arguments
     */
    

    public static void main(String[] args) {
       

        

        
        
        
        Register reg = new Register();
        reg.registrationMethod();
        
            login log = new login();
            log.loginMethod();
            
             
        
        Kanbanapp app = new Kanbanapp();
        app.runApplication();
        
       
       
        
        
    }
}


   


    // Getters and setters for all fields can be added here if needed.


// Unit tests should be created in a separate test class, using a testing framework like JUnit.
    
    
